﻿using System;
using DevExpress.ExpressApp.Xpo;

namespace XafFunctionalTest.Blazor.Server.Services {
    public class XpoDataStoreProviderAccessor {
        public IXpoDataStoreProvider DataStoreProvider { get; set; }
    }
}
